# Lucide Android — Vercel

Application Android pour Lucide, basée sur :
https://kdlucide.vercel.app/

## Compilation depuis un téléphone

Ce projet contient un workflow GitHub Actions dans `.github/workflows/build-apk.yml`.
Il compile automatiquement `Lucide.apk` sur un serveur GitHub, sans Android Studio sur le téléphone.

1. Importer ce projet dans un dépôt GitHub.
2. Ouvrir l'onglet **Actions**.
3. Choisir **Build Lucide APK**.
4. Appuyer sur **Run workflow**.
5. Attendre la fin du build.
6. Ouvrir le workflow terminé et télécharger l'artefact **Lucide-APK**.
7. L'archive contient `Lucide.apk`.

Le backend Groq reste côté Vercel : aucune clé API n'est intégrée dans l'application Android.
